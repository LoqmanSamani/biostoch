def main():
    print("Welcome to the biostoch package!")
    print("This package provides stochastic and deterministic simulation methods used in computational biology.")
    print("To get started, you can run specific examples or import the package modules for your own use.")
    print("for more information visit https://github.com/LoqmanSamani/biostoch")


if __name__ == "__main__":
    main()

