import numpy as np
import matplotlib.pyplot as plt
import pandas
import seaborn



class RateEquation(object):
    """The Reaction Rate Equations (RRE) will be implemented"""
    pass
