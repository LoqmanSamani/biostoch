import numpy as np
import matplotlib.pyplot as plt
import pandas
import seaborn


class TauLeap(object):
    """The Tau-Leaping Algorithm will be implemented"""
    pass
    
