import numpy as np
import matplotlib.pyplot as plt
import pandas
import seaborn



class ChemLang(object):
    """The Chemical Langevin Equation (CLE) will be implemented"""
    pass


