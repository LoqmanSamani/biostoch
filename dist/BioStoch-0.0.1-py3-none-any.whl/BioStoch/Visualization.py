import numpy as np
import matplotlib.pyplot as plt
import pandas
import seaborn



class Plot(object):
    """The results will be visualized using matplotlib library"""
    pass

