import numpy as np
import matplotlib.pyplot as plt
import pandas
import seaborn


class StochSim(object):
    """The Stochastic Simulation Algorithm (SSA) will be implemented"""
    pass
